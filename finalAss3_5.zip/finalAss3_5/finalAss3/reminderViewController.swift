//
//  reminderViewController.swift
//  finalAss3
//
//  Created by Wenyang Sun on 4/6/19.
//  Copyright © 2019 Wenyang Sun. All rights reserved.
//

import UIKit

class reminderViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var reminderList = [[String]]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reminderList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "remind")
        cell.textLabel!.text=reminderList[indexPath.row][0]+"  |  "+reminderList[indexPath.row][1]
        //cell.detailTextLabel!.text="time"
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete {
            reminderList.remove(at: indexPath.row)
            UserDefaults.standard.set(reminderList, forKey: "remindlist")
            tableview.reloadData()
        }
    }
    
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableview.reloadData()
        if let x = UserDefaults.standard.object(forKey: "remindlist"){
            reminderList = x as! [[String]]
        }
        // Do any additional setup after loading the view.
    }

}
