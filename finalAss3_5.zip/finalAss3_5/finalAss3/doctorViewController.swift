//
//  doctorViewController.swift
//  finalAss3
//
//  Created by Wenyang Sun on 3/6/19.
//  Copyright © 2019 Wenyang Sun. All rights reserved.
//
import Alamofire;
import UIKit

class doctorViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var idx = 0
    var doctorList = [[String]]()
    
    @IBOutlet weak var table: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (doctorList.count)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! docTableViewCell
        cell.name.text=doctorList[indexPath.row][0]
        cell.des.text=doctorList[indexPath.row][1]
        
        cell.imageView!.image=UIImage(named:"user")
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        idx = indexPath.row
        performSegue(withIdentifier: "profile", sender: self)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        let URL_DOCTORS = "http://wenyangsun.site/iosApp/fetchDoctors.php"
        let para: Parameters=[
            "fetch":true
        ]
        Alamofire.request(URL_DOCTORS, method: .post, parameters: para).responseJSON
            {
                response in
                
                if let result = response.result.value {
                    self.doctorList = result as! [[String]]
                    self.table.reloadData()
                    print(self.doctorList.count)
                }
                
        }
    }

}
