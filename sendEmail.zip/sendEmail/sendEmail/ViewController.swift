//
//  ViewController.swift
//  sendEmail
//
//  Created by Jia Liu on 29/5/19.
//  Copyright © 2019 Jia Liu. All rights reserved.
//

import UIKit
import MessageUI

class ViewController: UIViewController, MFMailComposeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func sendEma(_ sender: Any) {
        let mailComposeViewController = configureMailController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        }else {
            showMailError()
        }
        }
    }
    func configureMailController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self

        mailComposerVC.setToRecipients("aitanran1117@gmail.com")
        mailComposerVC.setSubject("hello")
        mailComposerVC.setMessageBody("how are you doing", isHTML: false)
        return mailComposerVC
    }
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title:"could not send email", message:"your devuce could not send email", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "OK"), style: <#type#>;.default;  handler;: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
        
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }


