//
//  profileViewController.swift
//  finalAss3
//
//  Created by Wenyang Sun on 5/6/19.
//  Copyright © 2019 Wenyang Sun. All rights reserved.
//

import UIKit

class profileViewController: UIViewController {
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var info: UILabel!
    @IBOutlet weak var name: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let docView = doctorViewController()
        //docView.doctorList[docView.idx][0]
        
        img.image = UIImage(named: "user")
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
