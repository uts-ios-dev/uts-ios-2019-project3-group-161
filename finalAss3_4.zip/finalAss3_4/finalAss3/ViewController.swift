//
//  ViewController.swift
//  finalAss3
//
//  Created by Wenyang Sun on 3/6/19.
//  Copyright © 2019 Wenyang Sun. All rights reserved.
//
import Alamofire
import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var passWord: UITextField!
    
    @IBAction func loginButton(_ sender: UIButton) {
        let parameterLog: Parameters=[
            "usernamelog":userName.text!,
            "passwordlog":passWord.text!
        ]
        let URL_USER_REGISTER = "http://wenyangsun.site/iosApp/login.php"
        //login verifiction
        Alamofire.request(URL_USER_REGISTER, method: .post, parameters: parameterLog).responseJSON
            {
                response in
                
                if let result = response.result.value {
                    
                    //converting data
                    let jsonData = result as! NSDictionary
                    
                    //displaying the message
                    let error : Bool = (jsonData.value(forKey: "errorlog") as! Bool?)!
                    let message = jsonData.value(forKey: "messagelog") as! String?
                    if(error){
                        let alert = UIAlertController(title: "Fail to log in!", message: message, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
                        self.present(alert, animated: true)
                    }
                    else{
                        self.performSegue(withIdentifier: "mainSegue", sender: nil)
                    }
                }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

