//
//  mainViewController.swift
//  Ass3
//
//  Created by DaisyLiu on 30/5/19.
//  Copyright © 2019 DaisyLiu. All rights reserved.
//

import UIKit

class mainViewController : UIViewController {
    
    @IBAction func setReminders(_ sender: UIButton) {
    }
    
    @IBAction func makeAppointments(_ sender: UIButton) {
    }
}
