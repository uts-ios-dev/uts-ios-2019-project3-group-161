//
//  ViewController.swift
//  Ass3
//
//  Created by DaisyLiu on 29/5/19.
//  Copyright © 2019 DaisyLiu. All rights reserved.
//

import Foundation
import UIKit

class LoginViewController: UIViewController {

    
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var passWord: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func loginButton(_ sender: Any) {
        
    }
}


