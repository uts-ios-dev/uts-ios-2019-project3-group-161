//
//  NotificationTableViewController.swift
//  Ass3
//
//  Created by DaisyLiu on 30/5/19.
//  Copyright © 2019 DaisyLiu. All rights reserved.
//

import UIKit
import UserNotifications


public func getScheduledNotification(with identifier: String, handler:@escaping (_ request:UNNotificationRequest?)-> Void) {
    
    
    var _:UNNotificationRequest? = nil
    UNUserNotificationCenter.current().getPendingNotificationRequests(completionHandler: { (requests) in
        
        for request  in  requests {
            if let request1 =  request.trigger as?  UNTimeIntervalNotificationTrigger {
                if (request.identifier == identifier) {
                    print("Timer interval notificaiton: \(request1.nextTriggerDate().debugDescription)")
                    handler(request)
                }
                break
                
            }
            if let request2 =  request.trigger as?  UNCalendarNotificationTrigger {
                if (request.identifier == identifier) {
                    handler(request)
                    if(request2.repeats) {
                        print(request)
                        print("Calendar notification: \(request2.nextTriggerDate().debugDescription) and repeats")
                    } else {
                        print("Calendar notification: \(request2.nextTriggerDate().debugDescription) does not repeat")
                    }
                    break
                }
                
            }
            if (request.trigger as? UNLocationNotificationTrigger) != nil {
            }
        }
    })
    
}


//class NotificationTableViewController: UITableViewController {
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(true)
//        tableView.reloadData()
//    }
//// Configuring the notification content
//    let reminderText = UNMutableNotificationContent()
//
//    // Deliver the notification in five seconds.
//    let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
//    let request = UNNotificationRequest(identifier: "FiveSecond", content: reminderText, trigger: trigger) // Schedule the notification.
//    let center = UNUserNotificationCenter.current()
//    center.add(request) { (error : Error?) in
//    if let theError = error {
//    // Handle any errors
//    }
//    }
//    // Configure the recurring date.
//    var dateComponents = DateComponents()
//    dateComponents.calendar = Calendar.current
//
//    dateComponents.weekday = 3  // Tuesday
//    dateComponents.hour = 14    // 14:00 hours
//
//    // Create the trigger as a repeating event.
//    let trigger = UNCalendarNotificationTrigger(
//        dateMatching: dateComponents, repeats: true)
//
//    // Create the request
//    let uuidString = UUID().uuidString
//    let request = UNNotificationRequest(identifier: uuidString,
//                                        content: content, trigger: trigger)
//
//    // Schedule the request with the system.
//    let notificationCenter = UNUserNotificationCenter.current()
//    notificationCenter.add(request) { (error) in
//    if error != nil {
    // Handle any errors.
//    }
//}
//}
//

