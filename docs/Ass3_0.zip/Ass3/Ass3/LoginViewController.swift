//
//  ViewController.swift
//  Ass3
//
//  Created by DaisyLiu on 29/5/19.
//  Copyright © 2019 DaisyLiu. All rights reserved.
//

import Foundation
import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
}


