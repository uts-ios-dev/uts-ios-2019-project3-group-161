//
//  addReminderViewController.swift
//  finalAss3
//
//  Created by ZHAN GE on 4/6/19.
//  Copyright © 2019 ZHAN GE. All rights reserved.
//
import UserNotifications
import UIKit

class addReminderViewController: UIViewController {
    
    var list = [[String]]()
    
    @IBOutlet weak var info: UITextField!
    @IBAction func dataPicker(_ sender: UIDatePicker) {
    }
    @IBOutlet weak var datepic: UIDatePicker!
    
    @IBAction func saveBtn(_ sender: UIBarButtonItem) {
        
        //get the date interval and set trigger to send notifications
        var dateComponent = DateComponents()
        dateComponent = getInterval()
        let content = UNMutableNotificationContent()
        content.title = "Timer triggered!"
        content.subtitle = "Note: " + info.text!
        content.badge = 1
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponent, repeats: false)
        let request = UNNotificationRequest(identifier: "timerdone", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
        
        //save information to the reminderlist
        let theFormatter = DateFormatter()
        theFormatter.dateStyle = .full
        let dateString = theFormatter.string(from: datepic.date)
        let singleReminder = [info.text!,dateString]
        if let x = UserDefaults.standard.object(forKey: "remindlist"){
            list = x as! [[String]]
        }
        list.append(singleReminder)
        UserDefaults.standard.set(list, forKey: "remindlist")
        
        //alert showing saved success
        let alert = UIAlertController(title: "Reminder added", message: "Successfully saved", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge], completionHandler:{didAllow, error in})
        // Do any additional setup after loading the view.
    }
    
    //calculate date interval and return a datecomponent
    func getInterval() -> DateComponents{
        
        let curdate = Date()
        let calendar = Calendar.current
        let curhour = calendar.component(.hour, from: curdate)
        let curminutes = calendar.component(.minute, from: curdate)
        let curday = calendar.component(.day, from: curdate)
        let curmonth = calendar.component(.month ,from: curdate)
        
        let hour = datepic.calendar.component(.hour, from: datepic.date)
        let minutes = datepic.calendar.component(.minute, from: datepic.date)
        let day = datepic.calendar.component(.day, from: datepic.date)
        let month = datepic.calendar.component(.month, from: datepic.date)
       
        let gapmonth = month-curmonth
        var gapday = day-curday
        var gaphour = hour-curhour
        var gapminute = minutes-curminutes

        if(gapmonth > 0 || gapday < 0){
            let alert = UIAlertController(title: "Please choose another time", message: "Sorry that date is not selectable for now", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        var dateComponents = DateComponents()
        if(gaphour<0){
            gapday = gapday - 1
            gaphour = gaphour + 24
        }
        if(gapminute<0){
            gaphour = gaphour - 1
            gapminute = gapminute + 60
        }

        dateComponents.hour = gaphour
        dateComponents.minute = gapminute
        dateComponents.day = gapday
        
        return dateComponents
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
