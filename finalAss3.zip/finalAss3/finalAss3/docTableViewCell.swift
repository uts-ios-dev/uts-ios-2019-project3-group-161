//
//  docTableViewCell.swift
//  finalAss3
//
//  Created by ZHAN GE on 3/6/19.
//  Copyright © 2019 ZHAN GE. All rights reserved.
//

import UIKit

class docTableViewCell: UITableViewCell {

    @IBOutlet weak var pic: UIImageView!
    @IBAction func buttonDetail(_ sender: Any) {
    }
    @IBOutlet weak var des: UILabel!
    @IBOutlet weak var name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
